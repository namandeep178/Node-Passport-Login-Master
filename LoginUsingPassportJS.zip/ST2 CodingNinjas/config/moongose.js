//require library
const moongose = require('mongoose');

//connect to database
moongose.connect('mongodb://localhost/Login_CN');

//to verify whether it is connected/acquire the connection
const db = moongose.connection;
db.on('error',console.error.bind(console,'Error connecting to db'));
db.once('open',function(){
    console.log('Successfully connected to database');
});